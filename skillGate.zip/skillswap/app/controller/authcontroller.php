<?php
require_once __DIR__ . '/../models/User.php';
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
class AuthController {
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'];
            $password = $_POST['password'];
         
            $userModel = new User();
            $user = $userModel->findByEmail($email);

            if ($user && password_verify($password, $user['password'])) {
                session_start();
                $_SESSION['user_id'] = $user['id'];
                header('Location: /dashboard');
                exit;
            } else {
                $error = "Invalid email or password";
                require __DIR__ . '/../views/auth/login.php';
            }
        } else {
            require __DIR__ . '/../views/auth/login.php';
        }
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name']);
            $email = trim($_POST['email']);
            $password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];

            $userModel = new User();
            $error = null;

            if ($password !== $confirm_password) {
                $error = "Passwords do not match";
            } elseif ($userModel->findByEmail($email)) {
                $error = "Email already registered";
            }

            if ($error) {
                require __DIR__ . '/../views/auth/register.php';
            } else {
                $userModel->create($name, $email, $password);
                header('Location: /login');
                exit;
            }
        } else {
            require __DIR__ . '/../views/auth/register.php';
        }
    }
}
