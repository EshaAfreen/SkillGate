<?php
return [
    'db_host' => 'localhost',
    'db_name' => 'skillswap',
    'db_user' => 'root',
    'db_pass' => '',
];
