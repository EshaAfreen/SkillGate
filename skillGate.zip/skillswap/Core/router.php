<?php
class Router {
    protected $routes = [];

    public function get($uri, $controllerAction) {
        $this->routes['GET'][$uri] = $controllerAction;
    }

    public function post($uri, $controllerAction) {
        $this->routes['POST'][$uri] = $controllerAction;
    }

    public function dispatch($uri, $method) {
        $methodRoutes = $this->routes[$method] ?? [];
        $action = $methodRoutes[$uri] ?? null;

        if (!$action) {
            http_response_code(404);
            echo "404 Not Found";
            exit;
        }

        list($controllerName, $methodName) = explode('@', $action);
        $controllerFile = __DIR__ . '/../app/controllers/' . $controllerName . '.php';

        if (!file_exists($controllerFile)) {
            http_response_code(500);
            echo "Controller not found";
            exit;
        }

        require_once $controllerFile;
        $controller = new $controllerName();
        if (!method_exists($controller, $methodName)) {
            http_response_code(500);
            echo "Method not found";
            exit;
        }

        $controller->$methodName();
    }
    
}
